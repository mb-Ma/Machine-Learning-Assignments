import torch
from torchvision import transforms# pytorch 视觉库提供了加载数据集的接口
from torchvision import datasets#pytorch 视觉库提供了加载数据集的接口用于下载并导入数据集
from torch.utils.data import  DataLoader
import torch.nn.functional as F #使用functional中的ReLu激活函数
import torch.optim as optim# 优化模块，封装了求解模型的一些优化器，如Adam SGD

#关于数据的准备
batch_size = 64# 由于使用批量训练的方法，需要定义每批的训练的样本数目
transform = transforms.Compose([
    transforms.ToTensor(),#将数据转化为图像张量
    transforms.Normalize((0.1307, ), (0.3081, ))#进行归一化处理，切换到0-1分布 （均值， 标准差）  
])
# root 用于指定数据集下载后的存放路径
# train 用于指定数据集下载后载入到训练集or测试集（True:载入训练集 False:载入测试集）
# transform 用于指定导入数据集需要对数据进行的操作（转换为tensor数据类型）
# download 设为True表示数据集由程序自动下载
# train_dataset下载训练集
train_dataset = datasets.MNIST(root='./dataset/mnist/',
                               train=True,
                               download=True,
                               transform=transform
                               )
# 使用Dataloader数据迭代器加载数据
# dataset 用于指定我们载入的数据集名称
# shuffle 在装载的过程会将数据随机打乱顺序并进行打包，便于后续训练
# train_loader装载训练集
train_loader = DataLoader(train_dataset,
                          shuffle=True,
                          batch_size=batch_size
                          )
# test_dataset下载测试集                         
test_dataset = datasets.MNIST(root='./dataset/mnist/',
                               train=False,
                               download=True,
                               transform=transform
                               )
# test_loader装载测试集                               
test_loader = DataLoader(test_dataset,
                          shuffle=False,
                          batch_size=batch_size
                          )

#构建模型
class Net(torch.nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        # 全连接层使用 torch.nn.Linear
        self.l1 = torch.nn.Linear(784, 512)
        self.l2 = torch.nn.Linear(512, 256)
        self.l3 = torch.nn.Linear(256, 128)
        self.l4 = torch.nn.Linear(128, 64)
        self.l5 = torch.nn.Linear(64, 10)
#前向传播
    def forward(self, x):
        x = x.view(-1, 784) #将数据转化为二维矩阵，可输入神经网络
        x = F.relu(self.l1(x))
        x = F.relu(self.l2(x))
        x = F.relu(self.l3(x))
        x = F.relu(self.l4(x))
        return self.l5(x)    #最后一层不需要激活函数，后面会接入softmax
#创建模型对象
model = Net()
#创建损失函数和优化器
criterion = torch.nn.CrossEntropyLoss()
#神经网络已经逐渐变大，需要设置冲量momentum=0.5
optimizer = optim.SGD(model.parameters(), lr=0.01, momentum=0.5)
#定义训练函数
#将一次迭代封装入函数中
def train(epoch):
    running_loss = 0.0
    #在这里data返回输入:inputs、输出target
    # 从迭代器抽取图片和标签
    for batch_idx, data in enumerate(train_loader, 0):   
        #特征值和目标值
        inputs, target = data 
        #梯度清零，将优化器内部参数梯度归零
        optimizer.zero_grad()
        # 将数据传入网络进行前向运算
        outputs = model(inputs)
        #计算损失的函数值
        loss = criterion(outputs, target)
        #loss.backward()反向传播
        loss.backward()
        #权重更新，通过梯度做一步参数更新
        optimizer.step()
        #计算每批次的损失值，将损失累加起来
        running_loss += loss.item()
        #设置每三百次进行一次输出或者一百等都行
        if batch_idx % 100 == 99:
            print('[%d, %5d] loss: %.3f' % (epoch + 1, batch_idx + 1, running_loss / 100))

#定义测试函数
def test():
    #准确分类的数量设为0
    correct = 0
    total = 0
    #只需要计算，不需要bp
    with torch.no_grad():  #不需要计算梯度
        #遍历数据集中的每一个batch
        for data in test_loader:  
            #保存测试的输入和输出
            images, labels = data  
            #得到预测输出
            outputs = model(images)
            #dim=1沿着索引为1的维度(行)
            # 找到概率最大的分类
            # dim=1表示输出所在行（样本）的最大值  dim=0表示输出所在列（类别）的最大值
            _, predicted = torch.max(outputs.data, dim=1)
            total += labels.size(0)
            #计算出分类正确的数目
            correct += (predicted == labels).sum().item()
    #输出测试集中正确分类的数目
    print('Accuracy on test set:%d %%' % (100 * correct / total))

if __name__ == '__main__':
    #选择迭代次数
    for epoch in range(20):
        #调用训练函数进行训练
        train(epoch)
        #训练完成后进行测试
        test()
