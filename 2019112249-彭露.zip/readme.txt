使用方法：
打开命令行后
1.安装依赖包
pip install -r requirements.txt
2.训练模型并预测
python nn.py

[注]当前默认参数为：
BATCH_SIZE=64
EPOCHS=20
MOMENTUM=0.5
LEARNING_RATE=0.01
optimizer=SGD
