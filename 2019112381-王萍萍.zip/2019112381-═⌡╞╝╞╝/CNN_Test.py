import torch
import numpy as np
from CNN_Train import Digit
from CNN_Train import test_loader
from CNN_Train import DEVICE
import torch.nn.functional as F
from sklearn.metrics import recall_score,f1_score,precision_score
loss_func = torch.nn.MSELoss()
def evaluate(model, device,test_dataloader):
    # 模型验证
    model.eval()
    # 正确率
    correct = 0.0
    # 测试损失
    test_loss = 0.0
    Recall = 0.0
    f1 = 0.0
    precision = 0.0
    num = 0.0
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += F.cross_entropy(output, target).item()
            pred = output.argmax(dim=1)
            correct += pred.eq(target.view_as(pred)).sum().item()
            Recall += recall_score(pred.cpu().numpy(), target.cpu().numpy(), average='weighted')
            f1 += f1_score(pred.cpu().numpy(), target.cpu().numpy(), average='weighted')
            precision += precision_score(pred.cpu().numpy(), target.cpu().numpy(), average='weighted')
            num += 1
        test_loss /= len(test_loader.dataset)
        loss_all = test_loss
        correct_all = correct / len(test_loader.dataset)
        print("Test Average loss:{:.4f},     Accuracy : {:.3f},        Recall : {:.3f}".format(
            test_loss, 100.0 * correct/len(test_loader.dataset), 100 * Recall / num
        ))
        print("                                F1 : {:.3f},             Precision : {:.3f}\n".format(
                100 * f1 / num, 100 * precision / num
            ))
        return loss_all, correct_all
best_model = Digit()
best_model.load_state_dict(torch.load('model.pth'))
best_model = best_model.cuda()
print("-----------------------------------------------------")
print("The best model to test:      ")
evaluate(best_model ,DEVICE,  test_loader)
print("-----------------------------------------------------")





