import torch
import cv2
import numpy as np
import copy
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from matplotlib import pyplot as plt
from sklearn.metrics import recall_score,f1_score,precision_score
# 定义超参数
# 参数：模型f(x,theta)中theta称为模型的参数，可以通过优化算法进行学习
# 超参数：用来定义模型结构或优化策略
BATCH_SIZE = 64  # 每批处理的数据
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 选用CPU或者GPU
EPOCHS = 30  # 训练数据集的轮次
MOMENTUM = 0.5
LEARNING_RATE = 0.01
epochs_loss_all = []
epochs_correct_all = []

# 构建transforms，对图像做处理
pipeline = transforms.Compose([
    transforms.ToTensor(),  # 将图片转换成tensor格式，即torch支持的类型
    transforms.Normalize((0.1307,),(0.3081,)),  # 归一化：降低模型复杂度
])

# 下载数据集
train_set = datasets.MNIST("data", train=True, download=True, transform=pipeline)
test_set = datasets.MNIST("data", train=False, download=True, transform=pipeline)
train_loader = DataLoader(train_set, batch_size=BATCH_SIZE, shuffle=True)
test_loader = DataLoader(test_set, batch_size=BATCH_SIZE, shuffle=True)

# 构建网络模型
class Digit(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv1 = nn.Conv2d(1, 10, 5)  # 1：灰度图片的通道  10：输出通道  5：卷积核
        self.conv2 = nn.Conv2d(10, 20, 3)  # 10：输入通道  20：输出通道  3：卷积核
        self.conv3 = nn.Conv2d(20, 30, 1)  # 20：输入通道  30：输出通道  1：卷积核
        self.fcl1 = nn.Linear(30*5*5, 300)  # 30*5*5:输入通道  300：输出通道
        self.fcl2 = nn.Linear(300, 10)  # 300:输入通道 10：输出通道
    def forward(self, x):
        input_size = x.size(0)
        x = self.conv1(x)  # 输入batch*1*28*28  输出batch*10*24*24(28-5+1=24)
        x = F.relu(x)  # 激活函数 保持shape不变
        x = F.max_pool2d(x, 2, 2)  # 输入batch*10*24*24 输出：batch*10*12*12

        x = self.conv2(x)  # 输入：batch*10*12*12  输出：batch*20*10*10（12-3+1）
        x = F.relu(x)
        x= F.max_pool2d(x, 2, 2)  # 输入batch*20*10*10  输出：batch*20*5*5

        x = self.conv3(x)  # 输入：batch*20*5*5  输出：batch*30*5*5
        x = F.relu(x)

        x = x.view(input_size, -1)  # -1:自动计算维度20*10*10=2000

        x = self.fcl1(x)  # 输入：batch*750  输出：batch*300
        x = F.relu(x)  # 保持shape不变

        x = self.fcl2(x)  # 输入：batch*300  输出：batch*10

        output = F.log_softmax(x, dim=1)  # 计算分类后每个数字的概率值

        return output


# 定义训练方法
def train_model(model, device, train_loader, optimizer, epoch):
    # 训练模型
    model.train()
    for batch_index, (data, target) in enumerate(train_loader):
        data, target = data.to(device), target.to(device)
        # 梯度初始化为0
        optimizer.zero_grad()
        # 结果
        output = model(data)
        # 计算损失
        loss = F.cross_entropy(output, target)
        # 反向传播
        loss.backward()
        # 参数优化
        optimizer.step()
        if batch_index %2000 == 0:
            print("Train Epoch: {} \t Loss : {:.6f}".format(epoch, loss.item()))

best_correct=0.0
best_recall=0.0
best_f1=0.0
best_precision=0.0
# 定义测试方法
def test_model(model, device, test_loader):
    # 模型验证
    model.eval()
    # 正确率
    correct = 0.0
    # 损失值
    test_loss = 0.0
    test_correct = 0.0
    # 召回率
    Recall = 0.0
    # F1值
    f1 = 0.0
    precision = 0.0
    num =0
    global best_correct
    global best_recall
    global best_f1
    global best_precision
    with torch.no_grad():
        for data, target in test_loader:
            data, target = data.to(device), target.to(device)
            output = model(data)
            test_loss += F.cross_entropy(output, target).item()
            pred = output.argmax(dim=1)
            correct += pred.eq(target.view_as(pred)).sum().item()
            Recall += recall_score(pred.cpu().numpy(), target.cpu().numpy(), average='weighted')
            f1 += f1_score(pred.cpu().numpy(), target.cpu().numpy(), average='weighted')
            precision += precision_score(pred.cpu().numpy(), target.cpu().numpy(), average='weighted')
            num += 1
        test_loss /= len(test_loader.dataset)
        test_correct = correct / len(test_loader.dataset)
        if test_correct > best_correct:
            best_correct = test_correct
            best_recall = 100*Recall/num
            best_f1 = 100*f1/num
            best_precision = 100*precision/num
            best_model_paras = copy.deepcopy(model.state_dict())
            # 保存最好的轮次模型的权重参数
            torch.save(model.state_dict(), './model.pth')
            # 保存最好的轮次的优化器参数
            torch.save(optimizer.state_dict(), './optimizer.pth')
        epochs_loss_all.append(test_loss)
        epochs_correct_all.append(correct / len(test_loader.dataset))
        print("Test Average loss:{:.4f},     Accuracy : {:.3f},        Recall : {:.3f}".format(
            test_loss, 100.0 * test_correct, 100*Recall/num
        ))
        print(
            "                                F1 : {:.3f},     Precision : {:.3f}\n".format(
                 100 * f1 / num, 100 * precision / num
            ))



# 定义优化器
model = Digit().to(DEVICE)
optimizer = optim.Adamax(model.parameters(), lr=LEARNING_RATE)


if __name__ == '__main__':
    # 调用
    print("---------------------START TRAIN-------------------")
    for epoch in range(1, EPOCHS+1):
        train_model(model, DEVICE, train_loader, optimizer, epoch)
        test_model(model, DEVICE, test_loader)
    print("-----------------------------------------------------")
    print("best correct: {:.3f}\t bast recall: {:.3f}\t best F1: {:.3f}\t best precision: {:.3f}".format(
            100*best_correct, best_recall, best_f1, best_precision
        ))
    plt.figure(figsize=(5, 10))
    plt.subplot(2, 1, 1)
    plt.plot(range(1,len(epochs_loss_all)+1), epochs_loss_all, 'ro-', label='Train loss')
    plt.legend(loc='best')
    plt.xlabel('epoch')
    plt.ylabel('Loss')

    plt.subplot(2, 1, 2)
    plt.plot(range(1,len(epochs_correct_all)+1), epochs_correct_all, 'ro-', label='Train Correct')
    plt.legend(loc='best')
    plt.xlabel('epoch')
    plt.ylabel('correct')
    plt.show()