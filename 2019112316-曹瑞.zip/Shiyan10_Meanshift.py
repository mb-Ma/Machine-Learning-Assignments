# 导入库
import matplotlib.pyplot as plt  
import numpy as np 
from sklearn import datasets
import time
from sklearn import metrics
import matplotlib as mpl
from sklearn.metrics import classification_report

## 导入数据
iris = datasets.load_iris() 
X = iris.data[:, :4]  # #表示我们取特征空间中的4个维度
Y = iris.target
print(X.shape)

## 定义基本函数
def get_HT(X,Y,label_pred,name='k_means'):
    mpl.rcParams['font.sans-serif'] = ['SimHei']
    mpl.rcParams['axes.unicode_minus'] = False 

    x0 = X[label_pred == 0]
    x1 = X[label_pred == 1]
    x2 = X[label_pred == 2]
    plt.scatter(x0[:, 0], x0[:, 1], c="red", marker='o', label='簇1')  
    plt.scatter(x1[:, 0], x1[:, 1], c="green", marker='*', label='簇2')  
    plt.scatter(x2[:, 0], x2[:, 1], c="blue", marker='+', label='簇3')  
    plt.xlabel('sepal length')  
    plt.ylabel('sepal width')  
    plt.legend(loc=2)  
    plt.title(name + "聚类结果")
    plt.show()
    score_funcs = [
         metrics.rand_score,         #RI（兰德指数）
        metrics.adjusted_rand_score,    #ARI（调整兰德指数）
        metrics.v_measure_score,        #均一性与完整性的加权平均
        metrics.mutual_info_score, #AMI（调整互信息）

        metrics.adjusted_mutual_info_score, #AMI（调整互信息）
        metrics.mutual_info_score,      #互信息
    ]
    for score_func in score_funcs:
        km_scores = score_func(Y, label_pred)
        print(name + "聚类:%s结果值:%.5f" % (score_func.__name__, km_scores))
from sklearn.cluster import MeanShift 
#  均值漂移,是一种核密度估计算法，它将每个点移动到密度函数的局部极大值点处
## Mean Shift算法,一般是指一个迭代的步骤,即先算出当前点的偏移均值,移动该点到其偏移均值,然后以此为新的起始点,继续移动,
## 直到满足一定的条件结束
ms = MeanShift(bandwidth=0.8,seeds=None,bin_seeding=False,min_bin_freq=1,cluster_all=True,n_jobs=1)
res = ms.fit(X)
label_pred = res.labels_  # 获取聚类标签
print(Y)
print(label_pred)
# measure_result = classification_report(Y, label_pred)
# print('measure_result = \n', measure_result)
get_HT(X,Y = Y,label_pred = label_pred,name = 'MeanShift')

