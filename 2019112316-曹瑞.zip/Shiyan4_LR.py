import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import pandas_profiling 
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn import metrics
from sklearn.model_selection import train_test_split
import warnings
warnings.filterwarnings("ignore") # Ignore warnings
# Load Data
df = pd.read_excel(r'H:/german.data')
df.head(10)  # Browse data samples


# logistic regression technique 
clf = LogisticRegression()
X,y = df.iloc[:,:-1],df['RESPONSE']
X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.4)
X_train
# Standardize the training data
ss=StandardScaler()
ss.fit(X_train)
x_train_stand=ss.transform(X_train)
x_test_stand=ss.transform(X_test)
#  Train the model 
clf.fit(x_train_stand,y_train)
print('------------------------------------------')
print("The modelling results:")
print('The slope of the logistic regression technique:',clf.coef_) # Print out the slope
print('The intercept of the logistic regression technique:',clf.intercept_) # Print out the intercept
# Prediction
y_pre = clf.predict(x_test_stand)
print('------------------------------------------')
print('The prediction results:','\n',y_pre)
# Calculate confusion matrix and plot it 
from sklearn.metrics import confusion_matrix
confusion_matrix = confusion_matrix(y_test, y_pre) 
plt.matshow(confusion_matrix, cmap=plt.cm.Greens) 
plt.colorbar()
for i in range(len(confusion_matrix)): 
    for j in range(len(confusion_matrix)):
        plt.annotate(confusion_matrix[i,j], xy=(i, j), horizontalalignment='center', verticalalignment='center')
plt.ylabel('True label')
plt.xlabel('Predicted label') 
plt.show()

# ROC curve
metrics.plot_roc_curve(clf,x_test_stand,y_test)
plt.show()
