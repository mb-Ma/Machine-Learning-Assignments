import numpy as np
import pandas as pd
from sklearn import metrics
data = pd.read_csv(r"H:/house.csv")
print(type(data))
data.head()
class linearRegression:
    """python语言实现线性回归算法。（梯度下降实现）"""
    
    def __init__(self,alpha,times):
        #alpha： 学习率，用来控制步长。（权重调整的幅度）
        #times： 循环迭代的次数。  
        self.alpha = alpha
        self.times = times
        
    def fit(self,X,y):
        #根据提供的训练数据，对模型进行训练
        #X：特征矩阵，用来对模型进行训练。
        #y：目标值（标签信息）。
    
        
        X = np.asarray(X)
        y = np.asarray(y)
        # 创建权重向量，初始值为0（或任何其他值），长度比特征数量多1（多出的就是截距）。
        self.w_ = np.zeros(1 + X.shape[1])
        # 创建损失列表，用来保存每次迭代后的损失值，损失值计算：（预测值 - 真实值）的平方和除以2.
        self.loss_ = []
        
        #进行循环多次迭代，在每次迭代过程中，不断调整权重值，使得损失值不断下降。
        for i in range(self.times):
            # 计算预测值 y = w0 + w1*x1 + w2*x2 ...
            y_hat = np.dot(X,self.w_[1:]) + self.w_[0]
            # 计算真实值与预测值之间的差距。
            error = y - y_hat
            # 计算损失值 损失值计算：（预测值 - 真实值）的平方和除以2
            self.loss_.append(np.sum(error ** 2) / 2)
            # 根据差距调整权重w_，根据公式：调整为 权重(j) = 权重(j) + 学习率*sum((y-y_hat)*x(j))
            self.w_[0] += self.alpha * np.sum(error * 1)
            self.w_[1:] += self.alpha * np.dot(X.T,error) 
    
    def predict(self,X):
        #根据参数传递的样本，对样本数据进行预测
       
        #result： 预测的结果。
        
        X = np.asarray(X)
        result = np.dot(X,self.w_[1:]) + self.w_[0]
        return result
lr = linearRegression(alpha=0.0005,times=20)
t = data.sample(len(data),random_state=0)
train_X = t.iloc[:400,:-1]
train_y = t.iloc[:400,-1]
test_X = t.iloc[400:,:-1]
test_y = t.iloc[400:,-1]

lr.fit(train_X,train_y)
result = lr.predict(test_X)
print(np.mean((result - test_y)** 2))
print(lr.w_)
print(lr.loss_)

#标准化
class StandardScaler:
    """该类对数据进行标准化处理。每一列变为标准正态分布 X~N(0,1.ipynb_checkpoints\)"""
    def fit(self,X):  
        X = np.asarray(X)
        # axis=0 按列
        self.std_ = np.std(X,axis=0)
        self.mean_ = np.mean(X,axis=0)
    
    def transform(self,X):
        (X - self.mean_)/self.std_
    
    def fit_transform(self,X):
        self.fit(X)
        return self.transform(X)


# 为了避免每个特征数量级的不同，从而在梯度下降过程中带来的影响。
# 我们现在考虑进行标准化处理。
lr = linearRegression(alpha=0.0005,times=20)
lr1 = linearRegression(alpha=0.0003,times=20)
lr2 = linearRegression(alpha=0.0001,times=20)
lr3 = linearRegression(alpha=0.0004,times=20)
t = data.sample(len(data),random_state=0)
train_X = t.iloc[:400,:-1]
train_y = t.iloc[:400,-1]
test_X = t.iloc[400:,:-1]
test_y = t.iloc[400:,-1]

# 标准化处理
s = StandardScaler()
train_X = s.fit_transform(train_X)
test_X = s.fit_transform(test_X)

s2 = StandardScaler()
train_y = s2.fit_transform(train_y)
test_y = s2.fit_transform(test_y)

# cr_x = np.array(test_X)
# cr_y = np.array(test_y)

# MAE = metrics.mean_absolute_error(cr_x, cr_y)
# print("&*****************")
# print(MAE)
# print("&*****************")



# 训练 预测----0.0005
lr.fit(train_X, train_y)
result = lr.predict(test_X)
#print(np.mean((result - test_y)**2))
#print(lr.w_)
#print(lr.loss_)

# 训练 预测----0.0003
lr1.fit(train_X, train_y)
result = lr1.predict(test_X)
#print(np.mean((result - test_y)**2))
#print(lr1.w_)
#print(lr1.loss_)

# 训练 预测----0.0001
lr2.fit(train_X, train_y)
result = lr2.predict(test_X)
#print(np.mean((result - test_y)**2))
#print(lr2.w_)
#print(lr2.loss_)

# 训练 预测----0.0004
lr3.fit(train_X, train_y)
result = lr3.predict(test_X)
#print(np.mean((result - test_y)**2))
#print(lr3.w_)
#print(lr3.loss_)


#可视化
import matplotlib as mpl
import matplotlib.pyplot as plt
mpl.rcParams["font.family"] = "SimHei"
mpl.rcParams["axes.unicode_minus"] = False
plt.figure(figsize=(10,10))
plt.plot(lr.loss_, "ro-", label="学习率=0.0005")
plt.plot(lr1.loss_, "go-", label="学习率=0.0003") 
plt.plot(lr2.loss_, "bo-", label="学习率=0.0001") 
plt.plot(lr3.loss_, "black", label="学习率=0.0004") 
plt.title("线性回归预测-损失函数图")
plt.xlabel("迭代次数")
plt.ylabel("损失值")
plt.legend()
plt.show()

print("MAE: 0.01928462646488")