from keras.datasets import mnist
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.metrics import classification_report
import datetime
 
(X_train,Y_train),(X_test,Y_test) = mnist.load_data()
X_train_1 = X_train.reshape(60000,784)
Y_train_1 = Y_train.reshape(-1,1)
 
starttime = datetime.datetime.now() #用来计算PCA+SVM总的计算时间
 
### 利用支持向量机训练
svc = SVC()  #这里利用默认参数就好，我试验过，默认参数的训练效果已经十分接近手动找最佳参数的效果了
x_train,x_test,y_train,y_test = train_test_split(X_train_1, Y_train_1, test_size = 0.25, random_state = 1)
y_train = y_train.reshape(-1,1).ravel() #最后加上.ravel()
svc.fit(x_train,y_train)
y_pred = svc.predict(x_test) #预测数据
accuracy = svc.score(x_test,y_test)
print("accuracy is ",accuracy)
 
endtime = datetime.datetime.now()
time = (endtime - starttime).seconds
print("time is ",time) 

#评价指标
measure_result = classification_report(y_test, y_pred)
print('measure_result = \n', measure_result)
 