import keras
from keras.datasets import mnist
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.metrics import classification_report
import datetime
print("**********")
(X_train,Y_train),(X_test,Y_test) = mnist.load_data()
X_train_1 = X_train.reshape(60000,784)
Y_train_1 = Y_train.reshape(-1,1)
#复制一份训练集，后面直接对原始数据降维
X_train_copy = X_train_1
 
starttime = datetime.datetime.now()  
 
###找到能够保留95%方差的n_components
pca_1=PCA(n_components=0.95, copy = False)  #copy = False指直接对数据集降维
                                            #调用PCA，会自动均值归一化
X_reduce = pca_1.fit_transform(X_train_1)
n_x = pca_1.n_components
 
###利用上面找到的n_components，降维
pca=PCA(n_components=n_x, copy = False)
X_reduce_fianl =pca.fit_transform(X_train_copy)
print("X_reduce_fianl :",X_reduce_fianl.shape)
# X_reduce_fianl : (60000, 154) ，在保留95%方差的情况下，从784降至154，效果赞！
 
### 利用支持向量机训练
svc = SVC()
x_train,x_test,y_train,y_test = train_test_split\
    (X_reduce_fianl, Y_train_1, test_size = 0.25, random_state = 1)
y_train = y_train.reshape(-1,1).ravel() 
svc.fit(x_train,y_train)
y_pred = svc.predict(x_test) #预测数据
accuracy = svc.score(x_test,y_test)
print("accuracy is ",accuracy)
 
endtime = datetime.datetime.now()
time = (endtime - starttime).seconds
print("time is ",time)

#评价指标
measure_result = classification_report(y_test, y_pred)
print('measure_result = \n', measure_result)
