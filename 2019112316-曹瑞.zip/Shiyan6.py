from sklearn.datasets import load_iris  # 导入方法类
 
iris = load_iris()  #导入数据集iris
iris_feature = iris.data    #特征数据
iris_target = iris.target   #分类数据
print (iris.data)          #输出数据集
print (iris.target)        #输出真实标签
print (len(iris.target) )
print (iris.data.shape )   #150个样本 每个样本4个特

import matplotlib.pyplot as plt
from sklearn.datasets import load_iris  # 导入方法类
 
iris = load_iris()  #导入数据集iris
iris_feature = iris.data    #特征数据
iris_target = iris.target   #分类数据
#print (iris.data)          #输出数据集
#print (iris.target)        #输出真实标签
#print (len(iris.target) )
#print (iris.data.shape )   #150个样本 每个样本4个特征
 
 #首先对从sklearn中导入决策树分类器，对数据集进行训练和分类
import pandas
#导入数据集iris
url = "H:/iris.data"
names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
dataset = pandas.read_csv(url, names=names) #读取csv数据
print(dataset.describe())

from sklearn import tree
from sklearn.tree import DecisionTreeClassifier      #导入决策树DTC包
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris  # 导入方法类
 
iris = load_iris()  #导入数据集iris
iris_feature = iris.data    #特征数据
iris_target = iris.target   #分类数据
 
clf = DecisionTreeClassifier()      # 所以参数均置为默认状态
clf.fit(iris.data, iris.target)     # 使用训练集训练模型
print(clf)
predicted = clf.predict(iris.data)    #使用模型对测试集进行预测
print(predicted)
print("精度是:{:.3f}".format(clf.score(iris.data, iris.target)))

# 因为叶结点都是纯的，输的深的很大，足以完美的记住训练数据的所有标签。
# 之前有线性模型也做个鸢尾花分类，线性模型的精度约为95%线性模型——鸢尾花分类
# 如果我们不限制决策树的深度，他的深度和复杂度都会变得很大。
# 银次未剪枝的树容易过度拟合，对新数据的泛化能力不佳。
# 我们将预剪枝应用到决策树上，这可以在完美拟合训练数据之前阻止树的展开。
# 一种选择是，在树到达一定深度后停止树的展开。代码如下：

clf = DecisionTreeClassifier(max_depth=3,random_state=0)
 
 
#输出精度：

#当我们不限制树得深度时
# 引入数据集
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier      #导入决策树DTC包
import matplotlib.pyplot as plt
from sklearn.datasets import load_iris  # 导入方法类
 
iris = load_iris()  #导入数据集iris
iris_feature = iris.data    #特征数据
iris_target = iris.target   #分类数据
 
clf = DecisionTreeClassifier()      # 所以参数均置为默认状态
clf.fit(iris.data, iris.target)     # 使用训练集训练模型
#print(clf)
predicted = clf.predict(iris.data)
#print(predicted)
print("精度是:{:.3f}".format(clf.score(iris.data, iris.target)))
# viz code 可视化 制作一个简单易读的PDF
#from sklearn.externals.six import StringIO
from six import StringIO
import pydot
#需要安装pydot包，用Anaconda Prompt安装，需要先安装graphviz再安装pydot，命令如下：
# conda install graphviz
# conda install pydot
dot_data = StringIO()
tree.export_graphviz(clf, out_file=dot_data,
                     feature_names=iris.feature_names,
                     class_names=iris.target_names,
                     filled=True, rounded=True,
                     special_characters=True)
graph = pydot.graph_from_dot_data(dot_data.getvalue())
# print(len(graph))  # 1
# print(graph)  # [<pydot.Dot object at 0x000001F7BD1A9630>]
# print(graph[0])  # <pydot.Dot object at 0x000001F7BD1A9630>
# graph.write_pdf("iris.pdf")
graph[0].write_pdf(".iris.pdf")
 
 
#输出如下：
#精度是:1.000