from sklearn import datasets
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from matplotlib.colors import ListedColormap
import matplotlib.pyplot as plt
import numpy as np
iris = datasets.load_iris()
X = iris.data[:, [2, 3]]
y = iris.target
X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.3,random_state=0)

sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std: object = sc.transform(X_test)


def plot_decision_regions(X, y, classifier, test_idx=None, resolution=0.02):
    # 设置marker generator和color map
    markers = ('s', 'x', 'o', '^', 'v')
    colors = ('red', 'blue', 'lightgreen', 'gray', 'cyan')
    cmap = ListedColormap(colors[:len(np.unique(y))])
    x1_min, x1_max = X[:, 0].min() - 1, X[:, 0].max() + 1
    x2_min, x2_max = X[:, 1].min() - 1, X[:, 1].max() + 1
    xx1, xx2 = np.meshgrid(np.arange(x1_min, x1_max, resolution),
                           np.arange(x2_min, x2_max, resolution))
    Z = classifier.predict(np.array([xx1.ravel(), xx2.ravel()]).T)
    Z = Z.reshape(xx1.shape)
    plt.contourf(xx1, xx2, Z, alpha=0.4, cmap=cmap)
    plt.xlim(xx1.min(), xx1.max())
    plt.ylim = (xx2.min(), xx2.max())
    X_test, y_test = X[test_idx, :], y[test_idx]
    for idx, cl in enumerate(np.unique(y)):  # np.unique:去除重复数据
        plt.scatter(x=X[y == cl, 0], y=X[y == cl, 1], alpha=0.8, c=cmap(idx), marker=markers[idx], label=cl)
    if test_idx:
        X_test, y_test = X[test_idx, :], y[test_idx]
        plt.scatter(X_test[:, 0], X_test[:, 1], c='black', alpha=0.8, linewidths=1, marker='o', s=10, label='test set')


X_combined_std = np.vstack((X_train_std, X_test_std))
y_combined = np.hstack((y_train, y_test))
svm = SVC(kernel='linear', C=1.0, random_state=0)# 使用线性核函数，设置C值为1
svm.fit(X_train_std, y_train)
plot_decision_regions(X_combined_std, y_combined, classifier=svm, test_idx=range(105,150))
plt.xlabel('petal length {standardized}')
plt.ylabel('petal width {standardized}')
plt.legend(loc='upper left')
plt.show()
from sklearn.model_selection import train_test_split
from sklearn import svm

data_Set = []
data_Set_x = []
data_Set_y = []


#打开数据集,字符串前加r表示raw string,防止路径字符串中存在的反斜杠带来的转义
data_file = open(r"H:/iris.csv")


#拆分数据集，取前四列为x，第五列为y
for line in data_file.readlines():
    lineArr = line.strip().split(',')
    data_Set.append(lineArr)
    data_Set_x.append(lineArr[0:4])
    data_Set_y.append(lineArr[4])

#按照7:3的比例分割训练集和测试集
data_train_x,data_test_x = train_test_split(data_Set_x,test_size = 0.3,random_state = 55)
data_train_y,data_test_y = train_test_split(data_Set_y,test_size = 0.3,random_state = 55)


"""
分别利用四种核函数进行训练，这些核函数都可以设置参数，例如
decision_function_shape='ovr'时，为one v rest，即一个类别与其他类别进行划分，
decision_function_shape='ovo'时，为one v one，即将类别两两之间进行划分，用二分类的方法模拟多分类的结果。
不设置的话会使用默认参数设置
"""
#使用linear线性核函数，C越大分类效果越好，但是可能过拟合
clf1 = svm.SVC(C=1,kernel='linear', decision_function_shape='ovr').fit(data_train_x,data_train_y)
#使用rbf径向基核函数,gamma值越小，分类界面越连续；gamma值越大，分类界面越“散”，分类效果越好，但有可能会过拟合。
clf2 = svm.SVC(C=1, kernel='rbf', gamma=1).fit(data_train_x,data_train_y)
#使用poly多项式核函数
clf3 = svm.SVC(kernel='poly').fit(data_train_x,data_train_y)
#使用sigmoid神经元激活核函数
clf4 = svm.SVC(kernel='sigmoid').fit(data_train_x,data_train_y)

#打印使用不同核函数进行分类时，训练集和测试集分类的准确率
print("linear线性核函数-训练集：",clf1.score(data_train_x, data_train_y))
print("linear线性核函数-测试集：",clf1.score(data_test_x, data_test_y))
print("rbf径向基核函数-训练集：",clf2.score(data_train_x, data_train_y))
print("rbf径向基函数-测试集：",clf2.score(data_test_x, data_test_y))
print("poly多项式核函数-训练集：",clf3.score(data_train_x, data_train_y))
print("poly多项式核函数-测试集：",clf3.score(data_test_x, data_test_y))
print("sigmoid神经元激活核函数-训练集：",clf4.score(data_train_x, data_train_y))
print("sigmoid神经元激活核函数-测试集：",clf4.score(data_test_x, data_test_y))

#使用decision_function()可以查看决策函数
print(clf1.decision_function(data_train_x))
#使用predict()可以查看预测结果
print(clf1.predict(data_train_x))
