import matplotlib.pyplot as plt
import numpy as np
import math
from sklearn.cluster import KMeans         
from sklearn.datasets import load_iris     #从sklearn库中导入鸢尾花数据集
iris = load_iris()
X = iris.data[:]  
#所引入的鸢尾花数据的形式就如上述所示，共有150行4个特征数据
#接下来，我们把它可视化，画个图看看什么样子吧
plt.scatter(X[:, 0], X[:, 1], c = "black", marker='o', label='label')
print(X)        
print(X.shape)          # 不妨顺便看看几行几列：（150，4） 
plt.xlabel('petal length')
plt.ylabel('petal width')
plt.legend(loc=2)
plt.show()   
#   k=3
estimator = KMeans(n_clusters=3)       #构造聚类器
estimator.fit(X)                       #聚类
label_pred = estimator.labels_         #获取聚类标签
#绘制K-Means结果
x0 = X[label_pred == 0]
x1 = X[label_pred == 1]
x2 = X[label_pred == 2]
plt.scatter(x0[:, 0], x0[:, 1], c = "red", marker='o', label='label0')
plt.scatter(x1[:, 0], x1[:, 1], c = "green", marker='*', label='label1')
plt.scatter(x2[:, 0], x2[:, 1], c = "blue", marker='+', label='label2')
plt.xlabel('petal length')
plt.ylabel('petal width')
plt.legend(loc=2)
plt.show()
##缺点：蓝色+和绿色* 两种类型 明显有混淆，分界线不明确

#改变K值再看一下效果
### 当 K=2的时候
estimator = KMeans(n_clusters=2)       #构造聚类器
estimator.fit(X)                       #聚类
label_pred = estimator.labels_         #获取聚类标签
x0 = X[label_pred == 0]
x1 = X[label_pred == 1]
plt.scatter(x0[:, 0], x0[:, 1], c = "red", marker='o', label='label0')
plt.scatter(x1[:, 0], x1[:, 1], c = "green", marker='*', label='label1')
plt.xlabel('petal length')
plt.ylabel('petal width')
plt.legend(loc=2)
plt.show()
#缺点：红色和绿色部分还是有一点点混淆

# 当 K=3的时候改变维度
X = iris.data[:,1:]            #表示我们只取特征空间中的后两个维度
print (X)
print("共有数据得个数和维度为：")
print(X.shape)

estimator = KMeans(n_clusters=3)       #构造聚类器
estimator.fit(X)                       #聚类
label_pred = estimator.labels_         #获取聚类标签
x0 = X[label_pred == 0]
x1 = X[label_pred == 1]
x2 = X[label_pred == 2]
print("三类的个数分别为：")
print(len(x0))
print(len(x1))
print(len(x2))
plt.scatter(x0[:, 0], x0[:, 1], c = "red", marker='o', label='label0')
plt.scatter(x1[:, 0], x1[:, 1], c = "green", marker='*', label='label1')
plt.scatter(x2[:, 0], x2[:, 1], c = "blue", marker='+', label='label2')
plt.xlabel('petal length')
plt.ylabel('petal width')
plt.legend(loc=2)
plt.show()