使用方法：
打开命令行后
1.安装依赖包
pip install numpy=1.21.5
pip install scipy=1.7.3
pip install matplotlib=3.5.0
2.改变原始数据集格式
python change_type.py
3.训练模型
python CNN_Train.py
4.用得到的最好模型预测
python CNN_Test.py

[注]当前默认参数为：
BATCH_SIZE=1000
EPOCHS=1
MOMENTUM=0.1
LEARNING_RATE=0.00001
optimizer=Adamax