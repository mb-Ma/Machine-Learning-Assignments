import numpy as np
import pandas as pd
import xgboost as xgb
from sklearn.ensemble import AdaBoostClassifier
from sklearn.model_selection import train_test_split   # cross_validation
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score  # 精确率  查准率P
from sklearn.metrics import recall_score  # 查全率  召回率  R
from sklearn.metrics import f1_score  # f1-score

#去忽略warnings警告
import warnings
warnings.filterwarnings("ignore")

'''基于softmax分类器的XGBoost'''
#鸢尾花数据
if __name__ == "__main__":

    '''加载数据'''
    path = u'H:\iris.data'  # 数据文件路径
    data = pd.read_csv(path, header=None)
    print(data)
    #样本数据和标签数据
    x, y = data[range(4)], data[4]
    #由字符串改为编码
    y = pd.Categorical(y).codes

    #训练集，测试集
    x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=1, test_size=30)
    '''AdaBoost+随机森林'''
    models=[
    #n_estimators:树的数目  criterion='entropy'使用“ID3”方式划分节点数据集
    ('随机森林',RandomForestClassifier(n_estimators=200,criterion='entropy')),
    #n_estimators:树的数目  min_samples_split：内部节点再划分所需最小样本数，可选参数，默认是2.
    #algorithm="SAMME":用于多分类  learning_rate=0.0005：学习率
    ('AdaBoost',AdaBoostClassifier(DecisionTreeClassifier(
        max_depth=3, min_samples_split=2),algorithm="SAMME",n_estimators=30,learning_rate=0.8))]
    for name,model in models:
        model = GaussianNB()
        model.fit(x_train,y_train)
        y_pred = model.predict(x_test)

        print("______________",name,"__________")
        print(name,'测试集正确个数：',accuracy_score(y_train,model.predict(x_train),normalize=False))
        print(name,'测试集正确率：',accuracy_score(y_train,model.predict(x_train)))
        print(name,'训练集正确个数：',accuracy_score(y_test,model.predict(x_test),normalize=False))
        print(name,'训练集正确率：',accuracy_score(y_test,model.predict(x_test)))
        print("测试数据：",y_test)
        print("预测数据：",y_pred)
        measure_result = classification_report(y_test, y_pred)
        print('measure_result = \n', measure_result)

