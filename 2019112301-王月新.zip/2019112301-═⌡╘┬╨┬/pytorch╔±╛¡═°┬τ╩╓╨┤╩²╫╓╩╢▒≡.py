# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 12:46:03 2022

@author: lenovo
"""
#使用pytorch完成手写数字的识别
import torch
import os
from torchvision.transforms import Compose,ToTensor,Normalize
import numpy as np
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
import PyQt5
from torch.optim import Adam
from torchvision import datasets, models, transforms
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST

BATCH_SIZE = 128
TEST_BATCH_SIZE = 1000
#准备数据集并查看
def get_data(train=True,batch_size = BATCH_SIZE):
    mnist=MNIST("./data",train=True,
                download=True,
                transform=transforms.Compose([transforms.ToTensor(),]))  # 下载数据，如果不存在会自动下载,并将其转化为tensor
  #  print(mnist)
   # print(mnist[0][0].shape)
    
    # 计算均值和方差
    data=[d[0].data.cpu().numpy() for d in mnist]
    mean=np.mean(data)
    std=np.std(data)
  #  print("数据的均值为：{},方差为：{}".format(mean,std))
    
    transform_fn = Compose([ToTensor(),Normalize(mean,std)])
    dataset = MNIST(root="./data",train=True,transform=transform_fn)
    data_loader = DataLoader(dataset,batch_size=batch_size,shuffle=True)

    return data_loader

#构建模型

class Model(nn.Module):
    def __init__(self):
        super(Model,self).__init__()
        self.fc1 = nn.Linear(1*28*28,28)
        self.fc2 = nn.Linear(28,10)
    
    def forward(self,input):
        #对数据形状进行修改
        x = input.view([input.size(0),1*28*28])
        #全连接操作
        x = self.fc1(x)
        #进行激活函数处理,形状不变
        x = F.relu(x)
        #输出层
        out = self.fc2(x)
        return F.log_softmax(out,dim=-1)
        
    #模型训练
model = Model()
optimizer = Adam(model.parameters(),lr= 0.001)

if os.path.exists("./model/model.pkl"):
    model.load_state_dict(torch.load("./model/model.pkl"))
    optimizer.load_state_dict(torch.load("./model/optimizer.pkl"))
    
def train(epoch):
#    mode = True
#   model.train(mode=mode)
    data_loader = get_data()
    for idx,(input,target) in enumerate(data_loader):
        optimizer.zero_grad()
        #调用模型得到预测值
        output = model(input)
        #得到损失
        loss = F.nll_loss(output,target)
        #进行反向传播
        loss.backward()
        #更新梯度
        optimizer.step()
        if idx%100 == 0:
            print(epoch,idx,loss.item())
        #模型保存和加载    
        if idx%100 ==0:
            torch.save(model.state_dict(),"./model/model.pkl")
            torch.save(optimizer.state_dict(),"./model/optimizer.pkl")
            
def test():
    loss_list = []
    acc_list = []

    test_dataloader = get_data(train=False,batch_size=TEST_BATCH_SIZE)
    for idx,(input,target) in enumerate(test_dataloader):
        with torch.no_grad():
            output = model(input)
            cur_loss = F.nll_loss(output,target)
            loss_list.append(cur_loss)
            #计算准确率
            pred = output.max(dim=-1)[-1]
            cur_acc = pred.eq(target).float().mean()
            acc_list.append(cur_acc)
    x1 = range(0,60)
    x2 = range(0,60)
    y1 = loss_list
    y2 = acc_list
    plt.subplot(2,1,1)
    plt.plot(x1,y1,'o-')
    plt.title("Test loss vs.epoches")
    plt.ylabel("Test loss")
    plt.show()
    plt.subplot(2,1,2)
    plt.plot(x2,y2,'o-')
    plt.title("Test precision vs.epoches")
    plt.ylabel("Test precision")
    plt.show()
    print("平均准确率，平均损失：",np.mean(acc_list),np.mean(loss_list))

if __name__ == '__main__':
    #模型训练5轮
    for i in range(5):
     train(i)   
    
    test()

    
    
















