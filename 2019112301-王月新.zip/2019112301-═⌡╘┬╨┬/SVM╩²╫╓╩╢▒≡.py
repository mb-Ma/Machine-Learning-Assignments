# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 23:52:24 2022

@author: lenovo
"""
#SVM实现手写数字识别
#导入标准库
import numpy as np
import pandas as pd
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import validation_curve
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import GridSearchCV
import matplotlib.pyplot as plt
import seaborn as sns
import os
os.listdir('./SVM模型数据')

train_data = pd.read_csv("./SVM模型数据/train.csv")
test_data = pd.read_csv("./SVM模型数据/test.csv")

train_data.shape
test_data.shape

train_data.head()
test_data.head()

train_data.isnull().sum().head(10)
test_data.isnull().sum().head(10)

#调用.describe()方法对训练集和测试集每列生成描述性统计
train_data.describe()
test_data.describe()

#统计标签列一共包括的类别数，并对其进行排序
order = list(np.sort(train_data['label'].unique()))
#print(order)

#可视化每类计数
#sns.countplot(train_data["label"])

#定义特征列和标签列，标签列为label，其余的为特征列
y = train_data['label']
X = train_data.drop(columns = 'label')
#print(train_data.shape)

#数据标准化
X=X/255.0
test_data = test_data/255.0
print("X:",X.shape)
print("test_data:",test_data.shape)

#数据切分，为节省时间，选择测试集的30%作为新的测试集，训练集的20%作为新的训练集
from sklearn.preprocessing import scale
X_scaled = scale(X)
X_train,X_test,y_train,y_test = train_test_split(X_scaled,y,
                                                 test_size = 0.3,
                                                 train_size = 0.2,
                                                 random_state = 10)
X_train.shape
X_test.shape

#将核函数设置为linear创建线性模型
model_linear = SVC(kernel='linear')
model_linear.fit(X_train,y_train)

#模型预测
y_pred = model_linear.predict(X_test)

#模型评估
#计算模型的准确率以及输出模型的混淆矩阵
from sklearn import metrics
from sklearn.metrics import confusion_matrix

#计算准确率
print("precision:",metrics.accuracy_score(y_true = y_test,
                                          y_pred = y_pred),"\n")

#混淆矩阵
print(metrics.confusion_matrix(y_true = y_test,y_pred = y_pred))

#设置核函数为rbf，创建非线性模型
non_linear_model = SVC(kernel = 'rbf')
non_linear_model.fit(X_train,y_train)

#模型预测
y_pred = non_linear_model.predict(X_test)

#计算模型的准确率以及输出模型的混淆矩阵
print("precision:",metrics.accuracy_score(y_true = y_test,
                                          y_pred = y_pred),"\n")
print(metrics.confusion_matrix(y_true = y_test,y_pred = y_pred))











