# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 23:28:58 2022

@author: lenovo
"""
#使用随机森林实现手写数字识别
import matplotlib.pyplot as plt
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import tensorflow.examples.tutorials.mnist.input_data as input_data
 
data_dir = 'MNIST_data/'
mnist = input_data.read_data_sets(data_dir,one_hot=False)
batch_size = 50000
batch_x,batch_y = mnist.train.next_batch(batch_size)
test_x = mnist.test.images[:10000]
test_y = mnist.test.labels[:10000]
 
print("start random forest")
a_acc = []
for i in range(10,200,10):
    clf_rf = RandomForestClassifier(n_estimators=i)
    clf_rf.fit(batch_x,batch_y)
 
    y_pred_rf = clf_rf.predict(test_x)
    acc_rf = accuracy_score(test_y,y_pred_rf)
    
    print(acc_rf)
    a_acc.append(acc_rf)

    print("n_estimators = %d, random forest accuracy:%f" %(i,acc_rf))

print("平均精确率为：",np.mean(a_acc))
print(a_acc)
x1 = range(0,19)
y1 = a_acc
plt.subplot(2,1,1)
plt.plot(x1,y1,'o-')
plt.title("Test precision vs.n_estimators")
plt.ylabel("Test precision")
plt.show()