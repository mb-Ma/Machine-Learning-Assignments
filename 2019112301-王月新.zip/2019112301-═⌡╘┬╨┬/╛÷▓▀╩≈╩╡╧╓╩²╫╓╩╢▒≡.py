# -*- coding: utf-8 -*-
"""
Created on Mon Jun 13 23:30:43 2022

@author: lenovo
"""
#决策树实现手写数字识别
from sklearn import tree
import numpy as np


dataset = np.load('./决策树模型数据/mnist.npz')

x_train = dataset['x_train']
y_train = dataset['y_train']
x_test = dataset['x_test']
y_test = dataset['y_test']

classifier = tree.DecisionTreeClassifier()
x_train = x_train.reshape(60000,784)
x_test = x_test.reshape(10000,784)

classifier.fit(x_train,y_train)
#计算准确率
score = classifier.score(x_test,y_test)
print("决策树模型的准确率为：",score)