# 机器学习实验课程设计

**2019114220 彭磊**

## 搭建环境

根据requirements.txt中的配置要求搭建相应实验环境

## 设置CNN模型参数

修改模型的batch_size、epoch、learning_rate等参数

当前参数：

```
batch_size = 64
learning_rate = 0.05
LossFun = nn.CrossEntropyLoss()
optimizer = optim.SGD()
```



## 训练模型

模型训练位于文件CNN.py中，设置好模型参数后运行该文件即可，运行后输出当前模型性能指标并且将模型参数文件保存在当前目录下

```python
python CNN.py
```

## 测试模型

确认当前目录是否存在模型参数文件，运行test.py文件，测试当前模型性能

```python
python test.py
```

