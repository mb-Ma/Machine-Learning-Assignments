import torch
from torch import nn
from torchvision import datasets, transforms, utils
import matplotlib.pyplot as plt
import torch.optim as optim
import datetime
import torch.nn.functional as Fun

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")  # 切换到GPU运算


# CNN结构
class MyCNN(nn.Module):
    def __init__(self):
        super(MyCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=5)  # 卷积核个数10 卷积核尺寸 5 步长1 无边缘填充
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)  # 2x2 maxpool
        self.conv2 = nn.Conv2d(32, 16, kernel_size=5)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)  # 2x2 maxpool
        self.fullc1 = nn.Linear(4 * 4 * 16, 128)  # 全连接层
        self.fullc2 = nn.Linear(128, 10)

    def forward(self, data):  # 前向传播
        # 28*28*1
        data = Fun.relu(self.conv1(data))  # 24x24x32
        data = self.pool1(data)  # 12x12x32
        data = Fun.relu(self.conv2(data))  # 8x8x16
        data = self.pool2(data)  # 4x4x16
        data = data.view(-1, 4 * 4 * 16)  # 展开为一维向量
        data = Fun.relu(self.fullc1(data))
        data = self.fullc2(data)
        return data


batch_size = 64
learning_rate = 0.05
times = 10

# 加载数据
dataset_train = datasets.MNIST(root="./data/",
                               transform=transforms.Compose([transforms.ToTensor()]),
                               train=True, download=True)
dataset_test = datasets.MNIST(root="./data/",
                              transform=transforms.Compose([transforms.ToTensor()]),
                              train=False, download=True)
# 数据预处理
X_train = torch.utils.data.DataLoader(dataset_train, batch_size=batch_size,
                                      shuffle=True)
X_test = torch.utils.data.DataLoader(dataset_test, batch_size=batch_size,
                                     shuffle=True)

net = MyCNN()
LossFun = nn.CrossEntropyLoss()  # 损失函数
optimizer = optim.SGD(net.parameters(), lr=learning_rate, momentum=0.9)  # 随机梯度下降

train_accs = []
train_loss = []
test_accs = []

# 训练模型
net = net.to(device)
for epoch in range(times):
    running_loss = 0.0
    for i, data in enumerate(X_train, 0):  # 0为下标起始位置
        inputs, labels = data[0].to(device), data[1].to(device)  # 数据送到GPU
        optimizer.zero_grad()  # 初始为0，清除上个batch的梯度信息

        outputs = net(inputs)  # 前向传播得到结果
        loss = LossFun(outputs, labels)  # 计算损失函数值
        loss.backward()  # 后向传播计算梯度
        optimizer.step()  # 使用优化器更新模型中的参数

        running_loss += loss.item()
        if ((i + 1) % 50 == 0) or (i == 0):  # 调整曲线图数据
            # print('[%d,%5d] loss :%.3f' % (epoch + 1, i + 1, running_loss / 50))
            running_loss = 0.0
            train_loss.append(loss.item())

            correct = 0
            total = 0
            _, predicted = torch.max(outputs.data, 1)
            total = labels.size(0)  # labels 的长度
            correct = (predicted == labels).sum().item()  # 预测正确的数目
            train_accs.append(correct / total)

plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False


def draw_train_process(title, iters, costs, accs, label_cost, lable_acc):
    plt.title(title, fontsize=20)
    # plt.xlabel("训练次数", fontsize=14)
    plt.plot(iters, costs, color='blue', label=label_cost)
    plt.plot(iters, accs, color='green', label=lable_acc)
    plt.legend()
    # plt.grid()
    plt.show()


train_iters = range(len(train_accs))
draw_train_process('lr={0}'.format(learning_rate), train_iters, train_loss, train_accs, '损失', '准确率')

# 保存模型
# PATH = './model_{0}.pth'.format(times)
PATH = 'CNN_model.pth'
torch.save(net.state_dict(), PATH)

