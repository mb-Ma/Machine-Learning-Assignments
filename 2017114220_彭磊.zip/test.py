import numpy as np
import torch
from torch import nn
from torchvision import datasets, transforms, utils
import matplotlib.pyplot as plt
import torch.optim as optim
import datetime
import torch.nn.functional as Fun
from sklearn.metrics import precision_score, recall_score, f1_score


# CNN结构
class MyCNN(nn.Module):
    def __init__(self):
        super(MyCNN, self).__init__()
        self.conv1 = nn.Conv2d(1, 32, kernel_size=5)
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(32, 16, kernel_size=5)
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.fullc1 = nn.Linear(4 * 4 * 16, 128)
        self.fullc2 = nn.Linear(128, 10)

    def forward(self, data):
        data = Fun.relu(self.conv1(data))
        data = self.pool1(data)
        data = Fun.relu(self.conv2(data))
        data = self.pool2(data)
        data = data.view(-1, 4 * 4 * 16)
        data = Fun.relu(self.fullc1(data))
        data = self.fullc2(data)
        return data


batch_size = 64
times = 5

# 加载数据
dataset_train = datasets.MNIST(root="./data/",
                               transform=transforms.Compose([transforms.ToTensor()]),
                               train=True, download=True)
dataset_test = datasets.MNIST(root="./data/",
                              transform=transforms.Compose([transforms.ToTensor()]),
                              train=False, download=True)
# 数据预处理
X_train = torch.utils.data.DataLoader(dataset_train, batch_size=batch_size,
                                      shuffle=True)
X_test = torch.utils.data.DataLoader(dataset_test, batch_size=batch_size,
                                     shuffle=True)

# PATH = './model_{0}.pth'.format(times)
PATH = 'CNN_model.pth'
test_net = MyCNN()
test_net.load_state_dict(torch.load(PATH))

# 测试集准确率
correct = 0
total = 0
with torch.no_grad():
    for data in X_test:
        images, labels = data
        outputs = test_net(images)
        _, predicted = torch.max(outputs.data, 1)
        total += labels.size(0)
        correct += (predicted == labels).sum().item()
print('测试集准确率: %f %%' % (100. * correct / total))

# 数字0-9准确率
class_correct = list(0. for i in range(10))
class_total = list(0. for i in range(10))
with torch.no_grad():
    for data in X_test:
        images, labels = data
        outputs = test_net(images)
        _, predicted = torch.max(outputs, 1)
        c = (predicted == labels)
        for i in range(len(c)):
            label = labels[i]
            class_correct[label] += c[i].item()
            class_total[label] += 1

for i in range(10):
    print('数字 %d 准确率: %4f %%' % (
        i, 100 * class_correct[i] / class_total[i]))


y_test = np.array([])
y_pred = np.array([])

with torch.no_grad():
    for data in X_test:
        images, labels = data
        outputs = test_net(images)
        _, predicted = torch.max(outputs.data, 1)
        y_test = np.append(y_test, labels.numpy())
        y_pred = np.append(y_pred, predicted.numpy())

print("精确率", precision_score(y_test, y_pred, average='weighted'))
print("召回率", recall_score(y_test, y_pred, average='weighted'))
print("F1度量值", f1_score(y_test, y_pred, average='weighted'))
