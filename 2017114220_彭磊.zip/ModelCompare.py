import numpy as np
from sklearn import svm
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import torchvision
from torchvision import transforms
from sklearn.tree import DecisionTreeClassifier, export_graphviz
from sklearn.svm import SVC
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import precision_score, recall_score, f1_score


def load_data():
    dataset_train = torchvision.datasets.MNIST(root='./data', train=True, transform=transforms.ToTensor())
    dataset_test = torchvision.datasets.MNIST(root='./data', train=False, transform=transforms.ToTensor())
    data_train = dataset_train.data
    X_train = data_train.numpy()
    X_test = dataset_test.data.numpy()
    X_train = np.reshape(X_train, (60000, 784))
    X_test = np.reshape(X_test, (10000, 784))
    Y_train = dataset_train.targets.numpy()
    Y_test = dataset_test.targets.numpy()

    return X_train, X_test, Y_train, Y_test


if __name__ == '__main__':
    # 导入数据
    X_train, X_test, y_train, y_test = load_data()

    # SVM
    model1 = SVC()
    model1.fit(X_train, y_train)
    y_pred1 = model1.predict(X_test)
    print("--------------------SVM-----------------------")
    print("精确率", precision_score(y_test, y_pred1, average='weighted'))
    print("召回率", recall_score(y_test, y_pred1, average='weighted'))
    print("F1度量值", f1_score(y_test, y_pred1, average='weighted'))

    # 朴素贝叶斯
    model2 = MultinomialNB()
    model2.fit(X_train, y_train)
    y_pred2 = model2.predict(X_test)
    print("--------------------Bayes-----------------------")
    print("精确率", precision_score(y_test, y_pred2, average='weighted'))
    print("召回率", recall_score(y_test, y_pred2, average='weighted'))
    print("F1度量值", f1_score(y_test, y_pred2, average='weighted'))

    # 决策树
    model3 = DecisionTreeClassifier()
    model3.fit(X_train, y_train)
    y_pred3 = model3.predict(X_test)
    print("-----------------DecisionTree---------------------")
    print("精确率", precision_score(y_test, y_pred3, average='weighted'))
    print("召回率", recall_score(y_test, y_pred3, average='weighted'))
    print("F1度量值", f1_score(y_test, y_pred3, average='weighted'))
